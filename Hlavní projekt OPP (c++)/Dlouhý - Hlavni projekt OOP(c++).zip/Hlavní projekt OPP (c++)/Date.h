﻿#pragma once
#ifndef DATE_H
#define DATE_H

struct Date {
    int den;
    int mesic;
    int rok;
};

#endif